const React = window.React;

export default function StyleTransferModule(props) {
  var savedPresetsFromConfig = props.config && props.config.presets ? props.config.presets : [];

  const [videoFile, setVideoFile] = React.useState(null);
  const [videoUrl, setVideoUrl] = React.useState('');
  const [activeFilters, setActiveFilters] = React.useState(null);
  const [savedPresets, setSavedPresets] = React.useState(savedPresetsFromConfig);
  const [showNewStyle, setShowNewStyle] = React.useState(false);
  const [analyzing, setAnalyzing] = React.useState(false);
  const [presetName, setPresetName] = React.useState('');
  const [tempAnalysis, setTempAnalysis] = React.useState(null);
  const [tempPhotoUrl, setTempPhotoUrl] = React.useState('');

  const t = function(sk, en) { return props.language === 'sk' ? sk : en; };

  // Sort: favorites first
  var sortedPresets = savedPresets.slice().sort(function(a, b) {
    var af = a.favorite ? 1 : 0;
    var bf = b.favorite ? 1 : 0;
    return bf - af;
  });

  var favorites = sortedPresets.filter(function(p) { return p.favorite; });
  var others = sortedPresets.filter(function(p) { return !p.favorite; });

  const savePresetsToConfig = function(presets) {
    var newConfig = { ...props.config, presets: presets };
    props.onSaveConfig(newConfig);
  };

  const analyzePhoto = function(file) {
    return new Promise(function(resolve) {
      var img = new Image();
      img.onload = function() {
        var canvas = document.createElement('canvas');
        var ctx = canvas.getContext('2d');
        canvas.width = 100; canvas.height = 100;
        ctx.drawImage(img, 0, 0, 100, 100);
        var data = canvas.getImageData(0, 0, 100, 100).data;
        var r=0,g=0,b=0,warm=0,cool=0,sat=0,bright=0,dark=0,pc=data.length/4;
        for(var i=0;i<data.length;i+=4){
          var pr=data[i],pg=data[i+1],pb=data[i+2];
          r+=pr;g+=pg;b+=pb;
          if(pr>pb+20)warm++; else if(pb>pr+20)cool++;
          var mx=Math.max(pr,pg,pb),mn=Math.min(pr,pg,pb);
          sat+=(mx-mn)/255;
          var br=(pr+pg+pb)/3;
          if(br>180)bright++; else if(br<75)dark++;
        }
        var avgSat=(sat/pc)*100,wm=warm/pc,cl=cool/pc,br=((r+g+b)/3/pc/255)*100;
        var f={brightness:Math.round(90+(br-50)*0.4),contrast:Math.round(100+(avgSat-50)*0.8),saturate:Math.round(80+avgSat*0.8),sepia:Math.round(wm*60),hueRotate:wm>0.4?Math.round(wm*-15):(cl>0.4?Math.round(cl*10):0),grayscale:0,blur:0};
        if(bright>0.3&&dark>0.2)f.contrast=Math.min(f.contrast+20,150);
        resolve({avgColor:{r:Math.round(r/pc),g:Math.round(g/pc),b:Math.round(b/pc)},filters:f});
      };
      img.src=URL.createObjectURL(file);
    });
  };

  const handleVideoSelect=function(e){var f=e.target.files[0];if(!f||!f.type.startsWith('video/'))return;setVideoFile(f);setVideoUrl(URL.createObjectURL(f));};
  const handleStylePhoto=async function(e){var f=e.target.files[0];if(!f)return;setTempPhotoUrl(URL.createObjectURL(f));setAnalyzing(true);var a=await analyzePhoto(f);setTempAnalysis(a);setAnalyzing(false);};

  const savePreset=function(){if(!presetName.trim()||!tempAnalysis)return;var np={id:Date.now().toString(),name:presetName.trim(),filters:tempAnalysis.filters,avgColor:tempAnalysis.avgColor,favorite:false,createdAt:new Date().toISOString()};var up=savedPresets.concat([np]);setSavedPresets(up);savePresetsToConfig(up);setPresetName('');setTempAnalysis(null);setTempPhotoUrl('');setShowNewStyle(false);};
  const applyPreset=function(p){setActiveFilters(p.filters);};
  const deletePreset=function(id,e){e.stopPropagation();var up=savedPresets.filter(function(p){return p.id!==id;});setSavedPresets(up);savePresetsToConfig(up);};
  const toggleFavorite=function(id,e){e.stopPropagation();var up=savedPresets.map(function(p){return p.id===id?{...p,favorite:!p.favorite}:p;});setSavedPresets(up);savePresetsToConfig(up);};

  const getFilterString=function(f){if(!f)return'';return'brightness('+f.brightness+'%) contrast('+f.contrast+'%) saturate('+f.saturate+'%) sepia('+f.sepia+'%) hue-rotate('+f.hueRotate+'deg)';};

  var styles={
    container:{height:'100%',display:'flex',flexDirection:'column',backgroundColor:'#0f0f0f',color:'#e0e0e0',fontFamily:'system-ui,sans-serif'},
    header:{height:'56px',display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 24px',borderBottom:'1px solid #2a2a2a',backgroundColor:'#1a1a1a'},
    title:{display:'flex',alignItems:'center',gap:'12px',fontSize:'16px',fontWeight:600},
    playerArea:{flex:1,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'20px',backgroundColor:'#0a0a0a',position:'relative'},
    video:{width:'100%',height:'100%',maxHeight:'60vh',borderRadius:'12px',objectFit:'contain'},
    noVideo:{textAlign:'center',color:'#666'},
    controls:{padding:'16px 24px',backgroundColor:'#1a1a1a',borderTop:'1px solid #2a2a2a',maxHeight:'35vh',overflow:'auto'},
    sectionTitle:{fontSize:'14px',fontWeight:600,marginBottom:'12px',color:'#fff',display:'flex',alignItems:'center',gap:'6px'},
    filterGrid:{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(90px,1fr))',gap:'10px'},
    filterCard:{padding:'10px',backgroundColor:'#0f0f0f',border:'2px solid #2a2a2a',borderRadius:'12px',cursor:'pointer',textAlign:'center',position:'relative'},
    filterCardActive:{padding:'10px',backgroundColor:'#4a9eff15',border:'2px solid #4a9eff',borderRadius:'12px',cursor:'pointer',textAlign:'center',position:'relative'},
    filterCardFav:{padding:'10px',backgroundColor:'#0f0f0f',border:'2px solid #ffd70040',borderRadius:'12px',cursor:'pointer',textAlign:'center',position:'relative'},
    filterCardFavActive:{padding:'10px',backgroundColor:'#ffd70015',border:'2px solid #ffd700',borderRadius:'12px',cursor:'pointer',textAlign:'center',position:'relative'},
    filterColor:{width:'36px',height:'36px',borderRadius:'50%',margin:'0 auto 6px',border:'2px solid #3a3a3a'},
    filterName:{fontSize:'11px',fontWeight:500,color:'#e0e0e0',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'},
    starBtn:{position:'absolute',top:'4px',right:'4px',background:'none',border:'none',cursor:'pointer',fontSize:'14px',padding:'2px',zIndex:2},
    addCard:{padding:'10px',backgroundColor:'#0f0f0f',border:'2px dashed #3a3a3a',borderRadius:'12px',cursor:'pointer',textAlign:'center',color:'#666'},
    addIcon:{fontSize:'24px',marginBottom:'2px'},
    labelBtn:{padding:'10px 20px',backgroundColor:'#4a9eff',color:'white',border:'none',borderRadius:'10px',cursor:'pointer',fontSize:'14px',fontWeight:500,display:'inline-block'},
    modal:{position:'fixed',top:0,left:0,right:0,bottom:0,backgroundColor:'rgba(0,0,0,0.8)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000},
    modalContent:{backgroundColor:'#1a1a1a',border:'1px solid #2a2a2a',borderRadius:'16px',padding:'24px',width:'400px',maxWidth:'90%'},
    input:{width:'100%',padding:'10px 12px',backgroundColor:'#0f0f0f',border:'1px solid #2a2a2a',borderRadius:'8px',color:'#e0e0e0',fontSize:'14px',marginBottom:'12px'},
    previewThumb:{width:'100%',height:'120px',objectFit:'cover',borderRadius:'8px',marginBottom:'12px'},
    btnRow:{display:'flex',gap:'8px',marginTop:'16px'},
    btnPrimary:{flex:1,padding:'10px',backgroundColor:'#4a9eff',color:'white',border:'none',borderRadius:'8px',cursor:'pointer',fontSize:'14px'},
    btnSecondary:{flex:1,padding:'10px',backgroundColor:'#2a2a2a',color:'#e0e0e0',border:'1px solid #3a3a3a',borderRadius:'8px',cursor:'pointer',fontSize:'14px'}
  };

  var renderPresetCard=function(preset){
    var isActive=activeFilters&&JSON.stringify(activeFilters)===JSON.stringify(preset.filters);
    var isFav=preset.favorite;
    var cardStyle=isFav?(isActive?styles.filterCardFavActive:styles.filterCardFav):(isActive?styles.filterCardActive:styles.filterCard);
    return React.createElement('div',{key:preset.id,style:cardStyle,onClick:function(){applyPreset(preset);}},
      React.createElement('button',{style:styles.starBtn,onClick:function(e){toggleFavorite(preset.id,e);}},isFav?'⭐':'☆'),
      React.createElement('div',{style:{...styles.filterColor,backgroundColor:'rgb('+preset.avgColor.r+','+preset.avgColor.g+','+preset.avgColor.b+')'}}),
      React.createElement('div',{style:styles.filterName},preset.name)
    );
  };

  return React.createElement('div',{style:styles.container},
    React.createElement('div',{style:styles.header},
      React.createElement('div',{style:styles.title},React.createElement('span',null,'🎨'),React.createElement('span',null,'Style Transfer')),
      !videoFile?React.createElement('label',{style:styles.labelBtn},'🎬 '+t("Nahrať video","Upload Video"),React.createElement('input',{type:'file',accept:'video/*',style:{display:'none'},onChange:handleVideoSelect})):
      React.createElement('label',{style:styles.labelBtn},'🔄 '+t("Iné video","Change Video"),React.createElement('input',{type:'file',accept:'video/*',style:{display:'none'},onChange:handleVideoSelect}))
    ),

    React.createElement('div',{style:styles.playerArea},
      !videoFile?React.createElement('div',{style:styles.noVideo},
        React.createElement('div',{style:{fontSize:'64px',marginBottom:'16px'}},'🎬'),
        React.createElement('p',{style:{fontSize:'18px',fontWeight:600}},t("Nahraj video","Upload a video")),
        React.createElement('p',{style:{fontSize:'14px',marginTop:'8px'}},t("A klikni na filter dole","Then click a filter below"))
      ):React.createElement('video',{src:videoUrl,controls:true,autoPlay:true,loop:true,style:{...styles.video,filter:getFilterString(activeFilters)}})
    ),

    React.createElement('div',{style:styles.controls},
      // Favorites section
      favorites.length>0?React.createElement('div',{style:{marginBottom:'16px'}},
        React.createElement('div',{style:styles.sectionTitle},'⭐ '+t("Obľúbené","Favorites")+' ('+favorites.length+')'),
        React.createElement('div',{style:styles.filterGrid},
          favorites.map(renderPresetCard)
        )
      ):null,

      // All filters section
      React.createElement('div',{style:styles.sectionTitle},'✨ '+t("Všetky filtre","All Filters")+' ('+savedPresets.length+')'),
      React.createElement('div',{style:styles.filterGrid},
        React.createElement('div',{style:styles.addCard,onClick:function(){setShowNewStyle(true);}},
          React.createElement('div',{style:styles.addIcon},'+'),
          React.createElement('div',{style:{fontSize:'11px'}},t("Nový štýl","New Style"))
        ),
        others.map(renderPresetCard)
      )
    ),

    showNewStyle?React.createElement('div',{style:styles.modal,onClick:function(){setShowNewStyle(false);}},
      React.createElement('div',{style:styles.modalContent,onClick:function(e){e.stopPropagation();}},
        React.createElement('h3',{style:{marginBottom:'16px',fontSize:'16px'}},'📷 '+t("Nový štýl","New Style")),
        !tempAnalysis?React.createElement('div',null,
          React.createElement('p',{style:{fontSize:'13px',color:'#888',marginBottom:'12px'}},t("Nahraj fotku s požadovanými farbami","Upload a photo with desired colors")),
          analyzing?React.createElement('p',{style:{color:'#4a9eff'}},t("Analyzujem...","Analyzing...")):
          React.createElement('label',{style:{...styles.labelBtn,width:'100%',textAlign:'center'}},'📁 '+t("Vybrať fotku","Select Photo"),React.createElement('input',{type:'file',accept:'image/*',style:{display:'none'},onChange:handleStylePhoto}))
        ):React.createElement('div',null,
          tempPhotoUrl?React.createElement('img',{src:tempPhotoUrl,style:styles.previewThumb}):null,
          React.createElement('input',{type:'text',style:styles.input,placeholder:t("Názov štýlu...","Style name..."),value:presetName,onChange:function(e){setPresetName(e.target.value);}}),
          React.createElement('div',{style:styles.btnRow},
            React.createElement('button',{style:styles.btnSecondary,onClick:function(){setShowNewStyle(false);setTempAnalysis(null);setPresetName('');}},t("Zrušiť","Cancel")),
            React.createElement('button',{style:styles.btnPrimary,onClick:savePreset},'💾 '+t("Uložiť","Save"))
          )
        )
      )
    ):null
  );
}
