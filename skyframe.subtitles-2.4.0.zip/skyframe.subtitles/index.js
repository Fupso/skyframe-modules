// ../../framesbuild-shim.js
var React = window.React;
var framesbuild_shim_default = React;
var useState = React.useState;
var useEffect = React.useEffect;
var useMemo = React.useMemo;
var useRef = React.useRef;
var useCallback = React.useCallback;
var useSyncExternalStore = React.useSyncExternalStore;
var createElement = React.createElement;
var Fragment = React.Fragment;

// index.jsx
var api = window.SkyFrame;
var t = (k, f) => api.t(k, f);
var { useState: useState2, useEffect: useEffect2, useSyncExternalStore: useSyncExternalStore2 } = framesbuild_shim_default;
var tt = (k, f, vars) => {
  let str = t(k, f);
  for (const [kk, vv] of Object.entries(vars ?? {})) str = str.replaceAll(`{${kk}}`, String(vv));
  return str;
};
var MODELS = ["base", "small", "medium", "large-turbo", "large"];
var initialState = {
  status: null,
  // {runtime_installed, models: []}
  model: "large-turbo",
  busy: false,
  busyLabel: "",
  progress: -1,
  error: ""
};
var state = { ...initialState };
var listeners = /* @__PURE__ */ new Set();
var store = {
  getState: () => state,
  setState(patch) {
    state = { ...state, ...typeof patch === "function" ? patch(state) : patch };
    listeners.forEach((l) => l());
  },
  subscribe(l) {
    listeners.add(l);
    return () => listeners.delete(l);
  }
};
function useStore() {
  return useSyncExternalStore2(store.subscribe, store.getState);
}
function watchJob(jobId, onProgress) {
  return new Promise((resolve) => {
    let unlisten;
    api.listenJob(jobId, (job) => {
      onProgress?.(job);
      if (job.status !== "running") {
        unlisten?.();
        resolve(job);
      }
    }).then((u) => {
      unlisten = u;
    });
  });
}
async function refreshStatus() {
  try {
    const st = await api.invoke("whisper_status", {});
    store.setState({ status: st });
  } catch {
  }
}
function fmtTime(s) {
  const ms = Math.round(s * 1e3);
  const mm = Math.floor(ms / 6e4);
  const ss = Math.floor(ms % 6e4 / 1e3);
  return `${mm}:${String(ss).padStart(2, "0")}.${String(Math.round(ms % 1e3 / 10)).padStart(2, "0")}`;
}
function parseTime(str) {
  const m = /^(\d+):(\d+)[.,](\d+)$/.exec(String(str).trim());
  if (!m) return null;
  return +m[1] * 60 + +m[2] + +m[3] / 100;
}
var lastWrittenPath = "";
var lastScale = 1;
async function commit(onChange, value, segments, timeScale = 1) {
  try {
    const ts = timeScale > 0 && isFinite(timeScale) ? timeScale : 1;
    const scaled = ts === 1 ? segments : segments.map((g) => ({ start: g.start * ts, end: g.end * ts, text: g.text }));
    const srtPath = await api.invoke("write_temp_srt", { segments: scaled, previous: value?.srtPath ?? null });
    lastWrittenPath = srtPath;
    lastScale = ts;
    onChange({ segments, srtPath });
  } catch (e) {
    store.setState({ error: String(e) });
  }
}
async function transcribe(ctx, onChange, value, lang) {
  const ts = ctx?.timeScale > 0 ? ctx.timeScale : 1;
  if (!ctx.mediaPath) return;
  store.setState({ busy: true, progress: -1, busyLabel: "", error: "" });
  try {
    const st = store.getState().status;
    if (!st?.runtime_installed) {
      store.setState({ busyLabel: t("install_runtime", "In\u0161talujem runtime\u2026") });
      await api.invoke("ensure_whisper_runtime", {});
    }
    const model = store.getState().model;
    if (!(st?.models ?? []).includes(model)) {
      store.setState({ busyLabel: t("install_model", "S\u0165ahujem model\u2026") });
      await api.invoke("ensure_whisper_model", { model });
    }
    const jobId = await api.invoke("transcribe_audio", {
      input: ctx.mediaPath,
      lang: lang || "auto",
      model,
      moduleId: api.moduleId
    });
    const res = await watchJob(
      jobId,
      (j) => store.setState({ progress: j.progress ?? -1, busyLabel: j.message || "" })
    );
    if (res.status === "done" && res.result) {
      const data = JSON.parse(res.result);
      const segments = (data.segments ?? []).map((g) => ({ start: g.start, end: g.end, text: g.text }));
      store.setState({ busy: false });
      await commit(onChange, value, segments, ts);
    } else if (res.status === "cancelled") {
      store.setState({ busy: false });
    } else {
      store.setState({ busy: false, error: res.message || "?" });
    }
  } catch (e) {
    store.setState({ busy: false, error: String(e) });
  }
}
var inpStyle = {
  background: "rgba(255,255,255,0.06)",
  border: "1px solid rgba(255,255,255,0.12)",
  borderRadius: 6,
  color: "inherit",
  fontSize: 11,
  padding: "3px 6px"
};
var btnStyle = {
  background: "rgba(255,255,255,0.08)",
  border: "none",
  borderRadius: 6,
  color: "inherit",
  fontSize: 11,
  padding: "3px 8px",
  cursor: "pointer"
};
var btnPrimary = { ...btnStyle, background: "#3b82f6", color: "#fff", fontWeight: 600 };
function makeSegOps(segments, value, onChange, timeScale) {
  const upd = (i, patch) => {
    const next = segments.map((g, j) => j === i ? { ...g, ...patch } : g);
    commit(onChange, value, next, timeScale);
  };
  const del = (i) => commit(onChange, value, segments.filter((_, j) => j !== i), timeScale);
  const add = () => {
    const last = segments[segments.length - 1];
    const start = last ? last.end : 0;
    commit(onChange, value, [...segments, { start, end: start + 2, text: "" }], timeScale);
  };
  const split = (i) => {
    const g = segments[i];
    const mid = (g.start + g.end) / 2;
    const words = g.text.split(" ");
    const half = Math.ceil(words.length / 2);
    const a = { ...g, end: mid, text: words.slice(0, half).join(" ") || g.text };
    const b = { start: mid, end: g.end, text: words.slice(half).join(" ") };
    commit(onChange, value, [...segments.slice(0, i), a, b, ...segments.slice(i + 1)], timeScale);
  };
  const merge = (i) => {
    if (i >= segments.length - 1) return;
    const a = segments[i], b = segments[i + 1];
    const joined = { start: a.start, end: b.end, text: (a.text + " " + b.text).trim() };
    commit(onChange, value, [...segments.slice(0, i), joined, ...segments.slice(i + 2)], timeScale);
  };
  const insertAfter = (i) => {
    const g = segments[i];
    const nxt = segments[i + 1];
    const start = g.end;
    const end = nxt ? Math.min(nxt.start, start + 2) : start + 2;
    commit(onChange, value, [...segments.slice(0, i + 1), { start, end: Math.max(end, start + 0.5), text: "" }, ...segments.slice(i + 1)], timeScale);
  };
  const shift = (i, delta) => {
    const g = segments[i];
    const start = Math.max(0, g.start + delta);
    const end = Math.max(start + 0.1, g.end + delta);
    upd(i, { start, end });
  };
  return { upd, del, add, split, merge, insertAfter, shift };
}
function SubtitlesField({ value, onChange, values, ctx }) {
  const timeScale = ctx?.timeScale > 0 ? ctx.timeScale : 1;
  const s = useStore();
  const segments = Array.isArray(value?.segments) ? value.segments : [];
  useEffect2(() => {
    refreshStatus();
    const iv = setInterval(refreshStatus, 6e3);
    return () => clearInterval(iv);
  }, []);
  useEffect2(() => {
    if (segments.length > 0 && (value?.srtPath !== lastWrittenPath || timeScale !== lastScale)) {
      void commit(onChange, value, segments, timeScale);
    }
  }, [timeScale]);
  return /* @__PURE__ */ framesbuild_shim_default.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 8 } }, /* @__PURE__ */ framesbuild_shim_default.createElement("div", { style: { display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" } }, /* @__PURE__ */ framesbuild_shim_default.createElement(
    "select",
    {
      value: s.model,
      disabled: s.busy,
      onChange: (e) => store.setState({ model: e.target.value }),
      style: { ...inpStyle, padding: "5px 8px" }
    },
    MODELS.map((m) => {
      const inst = (s.status?.models ?? []).includes(m);
      return /* @__PURE__ */ framesbuild_shim_default.createElement("option", { key: m, value: m }, m, inst ? " \u2713" : "");
    })
  ), /* @__PURE__ */ framesbuild_shim_default.createElement(
    "button",
    {
      style: btnPrimary,
      disabled: s.busy || !ctx.mediaPath,
      onClick: () => void transcribe(ctx, onChange, value, values?.lang ?? "auto")
    },
    s.busy ? `${s.busyLabel || t("transcribing", "Prepisujem\u2026")} ${s.progress >= 0 ? Math.round(s.progress) + " %" : ""}` : t("transcribe", "\u{1F399}\uFE0F Prep\xEDsa\u0165 re\u010D")
  )), s.error && /* @__PURE__ */ framesbuild_shim_default.createElement("div", { style: { color: "#f87171", fontSize: 11 } }, s.error), segments.length > 0 && /* @__PURE__ */ framesbuild_shim_default.createElement("div", { style: { fontSize: 11, opacity: 0.6 } }, tt("segments_below", "\u270F\uFE0F Segmenty ({n}) upravuje\u0161 v spodnom paneli \u2B07", { n: segments.length })));
}
function SubtitlesBottomPanel({ values, onChangeField, ctx }) {
  const timeScale = ctx?.timeScale > 0 ? ctx.timeScale : 1;
  const value = values?.subs ?? null;
  const onChange = (v) => onChangeField("subs", v);
  const segments = Array.isArray(value?.segments) ? value.segments : [];
  const ops = makeSegOps(segments, value, onChange, timeScale);
  const [saveMsg, setSaveMsg] = useState2("");
  const [saveBusy, setSaveBusy] = useState2(false);
  const saveSrt = async () => {
    if (segments.length === 0 || saveBusy) return;
    setSaveBusy(true);
    setSaveMsg("");
    try {
      const ts = timeScale > 0 && isFinite(timeScale) ? timeScale : 1;
      const scaled = ts === 1 ? segments : segments.map((g) => ({ start: g.start * ts, end: g.end * ts, text: g.text }));
      const p = await api.invoke("export_srt", { segments: scaled, outputName: null });
      setSaveMsg(tt("srt_saved", "\u2705 Ulo\u017Een\xE9: {p}", { p }));
    } catch (e) {
      setSaveMsg(tt("srt_failed", "\u274C {e}", { e: String(e) }));
    } finally {
      setSaveBusy(false);
    }
  };
  const miniBtn = { ...btnStyle, whiteSpace: "nowrap", flexShrink: 0 };
  return /* @__PURE__ */ framesbuild_shim_default.createElement("div", { style: { display: "flex", flexDirection: "column", height: "100%", minHeight: 0 } }, /* @__PURE__ */ framesbuild_shim_default.createElement("div", { style: { display: "flex", gap: 6, alignItems: "center", padding: "4px 8px", borderBottom: "1px solid rgba(255,255,255,0.08)", flexShrink: 0, flexWrap: "wrap" } }, /* @__PURE__ */ framesbuild_shim_default.createElement("span", { style: { fontSize: 11, opacity: 0.6 } }, "\u{1F4AC} ", tt("seg_count", "{n} titulkov", { n: segments.length })), /* @__PURE__ */ framesbuild_shim_default.createElement("button", { style: miniBtn, onClick: ops.add }, "\uFF0B ", t("add", "Prida\u0165 titulok")), segments.length > 0 && /* @__PURE__ */ framesbuild_shim_default.createElement("button", { style: miniBtn, disabled: saveBusy, onClick: () => {
    void saveSrt();
  } }, saveBusy ? t("srt_saving", "\u23F3 Uklad\xE1m\u2026") : `\u{1F4BE} ${t("srt_save", "Ulo\u017Ei\u0165 SRT")}`), segments.length > 0 && /* @__PURE__ */ framesbuild_shim_default.createElement("button", { style: { ...miniBtn, color: "#f87171" }, onClick: () => onChange(null) }, t("clear", "Zru\u0161i\u0165 titulky")), saveMsg && /* @__PURE__ */ framesbuild_shim_default.createElement("span", { style: { fontSize: 10, color: saveMsg.startsWith("\u2705") ? "#34d399" : "#f87171", wordBreak: "break-all" } }, saveMsg)), /* @__PURE__ */ framesbuild_shim_default.createElement("div", { style: { flex: 1, minHeight: 0, overflowY: "auto", padding: "4px 8px" } }, segments.length === 0 && /* @__PURE__ */ framesbuild_shim_default.createElement("div", { style: { fontSize: 11, opacity: 0.5, padding: 8 } }, t("no_segments", "Zatia\u013E \u017Eiadne titulky \u2014 prep\xED\u0161 re\u010D tla\u010Didlom v pravom paneli, alebo pridaj titulok ru\u010Dne.")), segments.map((g, i) => /* @__PURE__ */ framesbuild_shim_default.createElement("div", { key: i, style: { display: "flex", gap: 4, alignItems: "center", marginBottom: 3, padding: "3px 6px", background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 6 } }, /* @__PURE__ */ framesbuild_shim_default.createElement("span", { style: { fontSize: 10, opacity: 0.45, width: 20, textAlign: "right", flexShrink: 0 } }, i + 1), /* @__PURE__ */ framesbuild_shim_default.createElement(
    "input",
    {
      style: { ...inpStyle, width: 64, fontFamily: "monospace", flexShrink: 0 },
      defaultValue: fmtTime(g.start),
      key: `s${i}-${g.start}`,
      title: t("seg_start", "Za\u010Diatok"),
      onBlur: (e) => {
        const v = parseTime(e.target.value);
        if (v != null && v < g.end) ops.upd(i, { start: v });
        else e.target.value = fmtTime(g.start);
      }
    }
  ), /* @__PURE__ */ framesbuild_shim_default.createElement("span", { style: { fontSize: 10, opacity: 0.5, flexShrink: 0 } }, "\u2192"), /* @__PURE__ */ framesbuild_shim_default.createElement(
    "input",
    {
      style: { ...inpStyle, width: 64, fontFamily: "monospace", flexShrink: 0 },
      defaultValue: fmtTime(g.end),
      key: `e${i}-${g.end}`,
      title: t("seg_end", "Koniec"),
      onBlur: (e) => {
        const v = parseTime(e.target.value);
        if (v != null && v > g.start) ops.upd(i, { end: v });
        else e.target.value = fmtTime(g.end);
      }
    }
  ), /* @__PURE__ */ framesbuild_shim_default.createElement("span", { style: { fontSize: 10, opacity: 0.45, flexShrink: 0, width: 34 } }, (g.end - g.start).toFixed(1), "s"), /* @__PURE__ */ framesbuild_shim_default.createElement(
    "input",
    {
      style: { ...inpStyle, flex: 1, minWidth: 80, fontSize: 12 },
      defaultValue: g.text,
      key: `t${i}-${g.text}`,
      placeholder: t("text_ph", "text titulku\u2026"),
      onBlur: (e) => {
        if (e.target.value !== g.text) ops.upd(i, { text: e.target.value });
      }
    }
  ), /* @__PURE__ */ framesbuild_shim_default.createElement("button", { style: miniBtn, title: t("shift_back", "Posun\xFA\u0165 \u22120,5 s"), onClick: () => ops.shift(i, -0.5) }, "\u25C2 0,5s"), /* @__PURE__ */ framesbuild_shim_default.createElement("button", { style: miniBtn, title: t("shift_fwd", "Posun\xFA\u0165 +0,5 s"), onClick: () => ops.shift(i, 0.5) }, "\u25B8 0,5s"), /* @__PURE__ */ framesbuild_shim_default.createElement("button", { style: miniBtn, title: t("split", "Rozdeli\u0165"), onClick: () => ops.split(i) }, "\u2702 ", t("split", "Rozdeli\u0165")), /* @__PURE__ */ framesbuild_shim_default.createElement("button", { style: miniBtn, title: t("insert_after", "Vlo\u017Ei\u0165 za"), onClick: () => ops.insertAfter(i) }, "\uFF0B ", t("insert_after", "Vlo\u017Ei\u0165 za")), i < segments.length - 1 && /* @__PURE__ */ framesbuild_shim_default.createElement("button", { style: miniBtn, title: t("merge", "Spoji\u0165 s \u010Fal\u0161\xEDm"), onClick: () => ops.merge(i) }, "\u21F6 ", t("merge", "Spoji\u0165")), /* @__PURE__ */ framesbuild_shim_default.createElement("button", { style: { ...miniBtn, color: "#f87171" }, title: t("del", "Zmaza\u0165"), onClick: () => ops.del(i) }, "\u2715")))));
}
var clamp = (v, a, b) => Math.max(a, Math.min(b, v));
api.registerTool({
  icon: "\u{1F4AC}",
  labelKey: "title",
  bottomPanel: SubtitlesBottomPanel,
  fields: [
    {
      id: "lang",
      type: "select",
      labelKey: "lang",
      default: "auto",
      options: [
        { value: "auto", labelKey: "lang_auto" },
        { value: "sk", labelKey: "lang_sk" },
        { value: "cs", labelKey: "lang_cs" },
        { value: "en", labelKey: "lang_en" },
        { value: "de", labelKey: "lang_de" },
        { value: "ru", labelKey: "lang_ru" },
        { value: "zh", labelKey: "lang_zh" }
      ]
    },
    { id: "subs", type: "custom", labelKey: "segments", component: SubtitlesField },
    { id: "sec_style", type: "separator", labelKey: "sec_style" },
    { id: "fontSize", type: "number", labelKey: "font_size", min: 8, max: 72, step: 1, default: 20 },
    {
      id: "position",
      type: "select",
      labelKey: "position",
      default: "bottom",
      options: [
        { value: "bottom", labelKey: "pos_bottom" },
        { value: "top", labelKey: "pos_top" }
      ]
    },
    { id: "marginV", type: "number", labelKey: "margin_v", min: 0, max: 200, step: 2, default: 36 }
  ],
  buildStep(values, ctx) {
    if (ctx.kind !== "video") return null;
    const subs = values.subs;
    const segments = subs && Array.isArray(subs.segments) ? subs.segments : [];
    if (!subs?.srtPath || segments.length === 0) return null;
    const fs = clamp(Number(values.fontSize) || 20, 8, 72);
    const margin = clamp(Number(values.marginV) || 0, 0, 400);
    const align = values.position === "top" ? 8 : 2;
    const esc = String(subs.srtPath).replace(/\\/g, "\\\\").replace(/:/g, "\\:");
    const vf = `subtitles=filename='${esc}':force_style='FontName=Arial,FontSize=${fs},PrimaryColour=&H00FFFFFF,OutlineColour=&H80000000,BorderStyle=1,Outline=2,Shadow=0,Alignment=${align},MarginV=${margin || 36}'`;
    return { label: `\u{1F4AC} ${t("lbl_count", "titulky")} (${segments.length})`, vf };
  }
});
function SubtitlesToolStub() {
  return framesbuild_shim_default.createElement(
    "div",
    { style: { padding: 24, opacity: 0.7, fontSize: 13 } },
    t("stub", "N\xE1stroj Titulky n\xE1jde\u0161 v Editore \u2014 v pravom paneli n\xE1strojov.")
  );
}
export {
  SubtitlesToolStub as default
};
