import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";

// =============================================================================
// Types
// =============================================================================
interface StyleDef {
  id: string;
  nameKey: string;
  icon: string;
  color: string;
  asset: string;
  model: string;        // "universal" | "landscape" | "portrait"
  desc: string;         // description key
}

interface JobState {
  id: string | null;
  type: "preview" | "export" | null;
  percent: number;
  status: "idle" | "running" | "done" | "error";
  message: string;
}

interface VideoInfo {
  duration: number;
  width: number;
  height: number;
}

// =============================================================================
// Data - All styles with their target model
// =============================================================================
const ALL_STYLES: StyleDef[] = [
  // Animation - Landscape optimized
  { id: "anim_anime_hayao",   nameKey: "anim_anime_hayao",   icon: "🎌", color: "bg-pink-500/20 text-pink-400 border-pink-500/30",     asset: "animeganv2-hayao.onnx", model: "landscape", desc: "Jemný anime štýl Hayao Miyazaki" },
  { id: "anim_anime_shinkai", nameKey: "anim_anime_shinkai", icon: "🌸", color: "bg-rose-500/20 text-rose-400 border-rose-500/30",     asset: "animeganv2-shinkai.onnx", model: "landscape", desc: "Nádherné nebe Makoto Shinkai" },
  { id: "anim_cartoon",       nameKey: "anim_cartoon",       icon: "🖍️", color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",  asset: "whitebox-cartoon.onnx", model: "landscape", desc: "Kreslený film s plochými farbami" },
  { id: "anim_3d_cartoon",    nameKey: "anim_3d_cartoon",    icon: "🧊", color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30",      asset: "cartoon3d.onnx", model: "landscape", desc: "3D render s cartoon shaderom" },
  { id: "anim_sketch",        nameKey: "anim_sketch",        icon: "✏️", color: "bg-stone-500/20 text-stone-400 border-stone-500/30",    asset: "sketch.onnx", model: "landscape", desc: "Ručný ceruzkový náčrt" },
  { id: "anim_comic",         nameKey: "anim_comic",         icon: "💬", color: "bg-orange-500/20 text-orange-400 border-orange-500/30",  asset: "comic.onnx", model: "landscape", desc: "Komiksová kresba s okrajmi" },
  { id: "anim_watercolor",    nameKey: "anim_watercolor",    icon: "🎨", color: "bg-sky-500/20 text-sky-400 border-sky-500/30",         asset: "watercolor.onnx", model: "landscape", desc: "Jemný akvarel" },
  { id: "anim_oilpaint",      nameKey: "anim_oilpaint",      icon: "🖼️", color: "bg-amber-600/20 text-amber-500 border-amber-600/30",   asset: "oilpaint.onnx", model: "landscape", desc: "Klasická olejomaľba" },
  { id: "anim_pixel",         nameKey: "anim_pixel",         icon: "👾", color: "bg-purple-500/20 text-purple-400 border-purple-500/30",  asset: "pixelart.onnx", model: "landscape", desc: "8-bit retro pixel art" },
  // Animation - Portrait optimized
  { id: "anim_portrait_anime", nameKey: "anim_anime_hayao",  icon: "🎌", color: "bg-pink-600/20 text-pink-500 border-pink-600/30",     asset: "toonify-anime.onnx", model: "portrait", desc: "Anime štýl šetrný k tváram" },
  { id: "anim_portrait_cartoon", nameKey: "anim_cartoon",   icon: "🖍️", color: "bg-yellow-600/20 text-yellow-500 border-yellow-600/30", asset: "toonify-cartoon.onnx", model: "portrait", desc: "Cartoon s kvalitnými tvárami" },
  // Style transfer - Universal
  { id: "style_inferno",    nameKey: "style_inferno",    icon: "🔥", color: "bg-orange-600/20 text-orange-500 border-orange-600/30",  asset: "inferno.jpg", model: "universal", desc: "Ohnivá obloha, červeno-oranžové tóny" },
  { id: "style_golden",     nameKey: "style_golden",     icon: "🌅", color: "bg-amber-500/20 text-amber-400 border-amber-500/30",    asset: "golden.jpg", model: "universal", desc: "Zlatá hodinka, teplé tóny" },
  { id: "style_cyberpunk",  nameKey: "style_cyberpunk",  icon: "🌃", color: "bg-fuchsia-500/20 text-fuchsia-400 border-fuchsia-500/30", asset: "cyberpunk.jpg", model: "universal", desc: "Neon, fialovo-modrá atmosféra" },
  { id: "style_noir",       nameKey: "style_noir",       icon: "🎬", color: "bg-gray-500/20 text-gray-400 border-gray-500/30",      asset: "noir.jpg", model: "universal", desc: "Čiernobiely vysoký kontrast" },
  { id: "style_popart",     nameKey: "style_popart",     icon: "🍿", color: "bg-red-500/20 text-red-400 border-red-500/30",        asset: "popart.jpg", model: "universal", desc: "Andy Warhol pop art farby" },
];

// =============================================================================
// Translation helper
// =============================================================================
function useModuleT() {
  const { t: coreT } = (window as any).SkyFrame || { t: (k: string) => k };
  const [lang, setLang] = useState("sk");

  useEffect(() => {
    try {
      const s = JSON.parse(localStorage.getItem("skyframe-settings") || "{}");
      if (s.language) setLang(s.language);
    } catch {}
  }, []);

  const t = (key: string) => {
    try {
      const dicts = (window as any).__VIDEO_STYLES_LANGS__ || {};
      return dicts[lang]?.[key] || dicts["en"]?.[key] || coreT?.(key) || key;
    } catch { return key; }
  };
  return { t, lang };
}

// =============================================================================
// Video path helper
// =============================================================================
function useVideoSrc(path: string | null): string | undefined {
  const [src, setSrc] = useState<string | undefined>(undefined);
  useEffect(() => {
    if (!path) { setSrc(undefined); return; }
    let cancelled = false;
    (async () => {
      try {
        const { convertFileSrc } = await import("@tauri-apps/api/core");
        if (!cancelled) setSrc(convertFileSrc(path));
      } catch {
        if (!cancelled) setSrc(path);
      }
    })();
    return () => { cancelled = true; };
  }, [path]);
  return src;
}

// =============================================================================
// Main component
// =============================================================================
export default function VideoStylesModule() {
  const { t } = useModuleT();
  const { invoke, cancelJob } = (window as any).SkyFrame || {};

  // --- View state ---
  const [view, setView] = useState<"upload" | "detect" | "grid" | "detail">("upload");

  // --- Video ---
  const [videoPath, setVideoPath] = useState<string | null>(null);
  const [videoName, setVideoName] = useState("");
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const videoSrc = useVideoSrc(videoPath);
  const outputSrc = useVideoSrc(outputPath);
  const previewOutSrc = useVideoSrc(previewOutputPath);

  // --- Detection ---
  const [detectStatus, setDetectStatus] = useState<"idle" | "scanning" | "done">("idle");
  const [hasPeople, setHasPeople] = useState<boolean | null>(null);
  const [engine, setEngine] = useState<"landscape" | "portrait" | "universal">("landscape");

  // --- Style selection ---
  const [selectedStyle, setSelectedStyle] = useState<StyleDef | null>(null);
  const [stylePreview, setStylePreview] = useState<string | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);

  // --- Settings ---
  const [settings, setSettings] = useState({
    intensity: 85,
    fps: 30,
    resolution: "original" as string,
    keepAudio: true,
    previewPos: "middle" as "start" | "middle" | "end" | "custom",
    previewCustomSec: 0,
    previewDuration: 5,
  });

  // --- Job & Output ---
  const [job, setJob] = useState<JobState>({ id: null, type: null, percent: 0, status: "idle", message: "" });
  const [outputPath, setOutputPath] = useState<string | null>(null);
  const [previewOutputPath, setPreviewOutputPath] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [dragOver, setDragOver] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Load translations ---
  useEffect(() => {
    const load = async () => {
      try {
        const [sk, en] = await Promise.all([
          fetch("./lang/sk.json").then(r => r.json()),
          fetch("./lang/en.json").then(r => r.json()),
        ]);
        (window as any).__VIDEO_STYLES_LANGS__ = { sk, en };
      } catch {}
    };
    load();
  }, []);

  // --- Job listener ---
  useEffect(() => {
    if (!job.id) return;
    const handler = (e: Event) => {
      const d = (e as CustomEvent).detail;
      if (d.job_id !== job.id) return;
      if (d.status === "progress") {
        setJob(prev => ({ ...prev, percent: d.progress, message: d.message || prev.message }));
      } else if (d.status === "done") {
        setJob(prev => ({ ...prev, status: "done", percent: 100, message: t("done") }));
        if (prev.type === "preview") setPreviewOutputPath(d.output_path || null);
        else setOutputPath(d.output_path || null);
      } else if (d.status === "error") {
        setJob(prev => ({ ...prev, status: "error", message: d.message }));
        setError(d.message);
      }
    };
    window.addEventListener("skyframe-job-update", handler);
    return () => window.removeEventListener("skyframe-job-update", handler);
  }, [job.id, t]);

  // --- Helpers ---
  const handleFile = async (path: string) => {
    setVideoPath(path);
    setVideoName(path.split(/[\\/]/).pop() || "");
    setOutputPath(null);
    setPreviewOutputPath(null);
    setError("");
    setView("detect");
    setDetectStatus("idle");
    setHasPeople(null);
    setSelectedStyle(null);
    setStylePreview(null);
    try {
      const info = await invoke("get_video_info", { path });
      setVideoInfo(info as VideoInfo);
    } catch {}
  };

  const openFilePicker = async () => {
    try {
      const { open } = await import("@tauri-apps/plugin-dialog");
      const sel = await open({ multiple: false, filters: [{ name: "Video", extensions: ["mp4", "mov", "avi", "mkv", "m4v"] }] });
      if (sel && !Array.isArray(sel)) handleFile(sel);
    } catch {
      fileInputRef.current?.click();
    }
  };

  // --- Detection ---
  const startDetection = async () => {
    if (!videoPath) return;
    setDetectStatus("scanning");
    try {
      const result = await invoke("detect_people_in_video", { path: videoPath, sample_count: 20 });
      const hasPpl = (result as any).has_people;
      setHasPeople(hasPpl);
      setEngine(hasPpl ? "portrait" : "landscape");
      setDetectStatus("done");
    } catch {
      setHasPeople(false);
      setEngine("landscape");
      setDetectStatus("done");
    }
  };

  const handleManualDetect = (hasPpl: boolean) => {
    setHasPeople(hasPpl);
    setEngine(hasPpl ? "portrait" : "landscape");
    setDetectStatus("done");
  };

  // --- Generate preview from user's video ---
  const generateStylePreview = async () => {
    if (!videoPath || !selectedStyle) return;
    setPreviewLoading(true);
    setStylePreview(null);

    try {
      const midSec = videoInfo ? videoInfo.duration / 2 : 5;
      const result = await invoke<string>("preview_single_frame", {
        video_path: videoPath,
        time_sec: midSec,
        style_id: selectedStyle.id,
        asset: selectedStyle.asset,
        engine: engine,
        intensity: settings.intensity / 100,
      });
      setStylePreview(result);
    } catch {
      setStylePreview(null);
    } finally {
      setPreviewLoading(false);
    }
  };

  // --- Process ---
  const runProcess = async (type: "preview" | "export") => {
    if (!videoPath || !selectedStyle) { setError(t("error_no_style")); return; }
    setError("");
    setJob({ id: null, type, percent: 0, status: "running", message: t("extracting") });
    if (type === "preview") setPreviewOutputPath(null);
    else setOutputPath(null);

    try {
      const params: any = {
        input: videoPath,
        mode: type,
        style_id: selectedStyle.id,
        asset: selectedStyle.asset,
        engine: engine,
        intensity: settings.intensity / 100,
        fps: settings.fps,
        resolution: settings.resolution,
        keep_audio: settings.keepAudio,
      };

      if (type === "preview") {
        const dur = videoInfo?.duration || 0;
        let start = 0;
        switch (settings.previewPos) {
          case "start": start = 0; break;
          case "middle": start = Math.max(0, (dur / 2) - (settings.previewDuration / 2)); break;
          case "end": start = Math.max(0, dur - settings.previewDuration); break;
          case "custom": start = Math.min(settings.previewCustomSec, Math.max(0, dur - settings.previewDuration)); break;
        }
        params.preview_start_sec = start;
        params.preview_duration_sec = settings.previewDuration;
      }

      const jobId = await invoke("process_video_style", params);
      setJob({ id: jobId, type, percent: 5, status: "running", message: t("extracting") });
    } catch (e: any) {
      setJob({ id: null, type, percent: 0, status: "error", message: String(e) });
      setError(String(e));
    }
  };

  const handleCancel = () => {
    if (job.id && job.status === "running") {
      cancelJob(job.id);
      setJob({ id: null, type: null, percent: 0, status: "idle", message: "" });
    }
  };

  const handleSaveAs = async () => {
    const target = outputPath || previewOutputPath;
    if (!target) return;
    try {
      const { save } = await import("@tauri-apps/plugin-dialog");
      const dest = await save({ defaultPath: target.split(/[\\/]/).pop() });
      if (dest) await invoke("copy_file", { from: target, to: dest });
    } catch {}
  };

  const handleUseAsInput = () => {
    const target = outputPath || previewOutputPath;
    if (!target) return;
    handleFile(target);
  };

  // Filter styles by engine
  const visibleStyles = useMemo(() => {
    if (engine === "universal") return ALL_STYLES.filter(s => s.model === "universal");
    if (engine === "portrait") return ALL_STYLES.filter(s => s.model === "portrait" || s.model === "landscape");
    return ALL_STYLES.filter(s => s.model === "landscape" || s.model === "universal");
  }, [engine]);

  // =============================================================================
  // Render
  // =============================================================================
  return (
    <div className="h-full overflow-y-auto bg-bg text-text">
      <input ref={fileInputRef} type="file" accept="video/*" className="hidden" onChange={e => {
        const f = e.target.files?.[0];
        if (f) handleFile(f.name);
      }} />

      <div className="max-w-5xl mx-auto p-6 space-y-6">

        {/* Header */}
        <div className="flex items-center gap-3">
          <span className="text-3xl">🎨</span>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">{t("title")}</h1>
            <p className="text-sm text-text-dim">{t("subtitle")}</p>
          </div>
        </div>

        {/* ========================================== */}
        {/* VIEW: Upload */}
        {/* ========================================== */}
        {view === "upload" && (
          <div className={`rounded-2xl border-2 border-dashed transition-all ${
            dragOver ? "border-accent bg-accent/5" : "border-border bg-bg-card"
          } p-8`}
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={() => setDragOver(false)}
          >
            <div className="text-center py-10">
              <div className="text-4xl mb-3">🎬</div>
              <p className="text-text-dim mb-4">{t("drop_video")}</p>
              <button onClick={openFilePicker} className="px-5 py-2.5 rounded-xl bg-accent/10 text-accent border border-accent/20 hover:bg-accent/20 transition-colors text-sm font-medium">
                {t("browse")}
              </button>
            </div>
          </div>
        )}

        {/* ========================================== */}
        {/* VIEW: Detection */}
        {/* ========================================== */}
        {view === "detect" && videoPath && (
          <div className="bg-bg-card border border-border rounded-2xl p-5 space-y-4 animate-fade-in">
            <h2 className="text-sm font-semibold text-text-dim uppercase tracking-wider">{t("detect_title")}</h2>

            {/* Video thumbnail */}
            <div className="relative rounded-xl overflow-hidden">
              <video src={videoSrc} className="w-full h-32 object-cover" />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2">
                <span className="text-xs text-white font-medium">{videoName}</span>
              </div>
            </div>

            {detectStatus === "idle" && (
              <button onClick={startDetection} className="w-full py-3 bg-accent text-white rounded-xl font-semibold hover:bg-accent-dim transition-colors">
                {t("detect_auto")}
              </button>
            )}

            {detectStatus === "scanning" && (
              <div className="flex items-center gap-3 p-4 bg-accent/5 border border-accent/20 rounded-xl">
                <span className="w-5 h-5 border-2 border-accent/30 border-t-accent rounded-full animate-spin" />
                <span className="text-sm text-accent">{t("detect_scanning")}</span>
              </div>
            )}

            {detectStatus === "done" && (
              <div className={`p-4 rounded-xl border ${
                hasPeople ? "bg-orange-500/10 border-orange-500/30 text-orange-400" : "bg-green-500/10 border-green-500/30 text-green-400"
              }`}>
                <div className="flex items-center gap-2">
                  <span className="text-xl">{hasPeople ? "👥" : "🌄"}</span>
                  <span className="text-sm font-medium">{hasPeople ? t("detect_result_people") : t("detect_result_landscape")}</span>
                </div>
              </div>
            )}

            {/* Manual override */}
            <div className="flex gap-2">
              <button onClick={() => handleManualDetect(false)}
                className={`flex-1 py-2 rounded-lg text-xs font-medium border transition-all ${
                  hasPeople === false ? "bg-accent/15 text-accent border-accent/30" : "bg-bg text-text-dim border-border hover:border-accent/20"
                }`}>
                {t("detect_manual_no")}
              </button>
              <button onClick={() => handleManualDetect(true)}
                className={`flex-1 py-2 rounded-lg text-xs font-medium border transition-all ${
                  hasPeople === true ? "bg-accent/15 text-accent border-accent/30" : "bg-bg text-text-dim border-border hover:border-accent/20"
                }`}>
                {t("detect_manual_yes")}
              </button>
            </div>

            {detectStatus === "done" && (
              <button onClick={() => setView("grid")}
                className="w-full py-3 bg-accent text-white rounded-xl font-semibold hover:bg-accent-dim transition-colors">
                {t("styles_title")} →
              </button>
            )}
          </div>
        )}

        {/* ========================================== */}
        {/* VIEW: Style Grid */}
        {/* ========================================== */}
        {view === "grid" && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-text-dim uppercase tracking-wider">{t("styles_title")}</h2>
                <p className="text-xs text-text-dim">{t("styles_subtitle_animation")}</p>
              </div>
              <button onClick={() => setView("detect")} className="text-xs text-accent hover:underline">
                {hasPeople ? "👥" : "🌄"} {t("detect_title")}
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {visibleStyles.map(style => (
                <button
                  key={style.id}
                  onClick={() => { setSelectedStyle(style); setView("detail"); setStylePreview(null); }}
                  className="group relative rounded-xl border border-border bg-bg-card overflow-hidden hover:border-accent/50 transition-all text-left"
                >
                  {/* Illustration image */}
                  <div className="aspect-[4/3] bg-black relative overflow-hidden">
                    <img
                      src={`./assets/previews/${style.id}.jpg`}
                      alt={t(style.nameKey)}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                    />
                    <div className="absolute inset-0 flex items-center justify-center text-3xl pointer-events-none">
                      {style.icon}
                    </div>
                    {/* Model badge */}
                    <div className="absolute top-1.5 right-1.5">
                      <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-medium ${
                        style.model === "portrait" ? "bg-orange-500/80 text-white" :
                        style.model === "universal" ? "bg-purple-500/80 text-white" :
                        "bg-green-500/80 text-white"
                      }`}>
                        {style.model === "portrait" ? "👥" : style.model === "universal" ? "🌐" : "🌄"}
                      </span>
                    </div>
                  </div>
                  {/* Label */}
                  <div className="p-2.5">
                    <div className="text-sm font-semibold text-text">{t(style.nameKey)}</div>
                    <div className="text-[10px] text-text-dim mt-0.5">{style.desc}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ========================================== */}
        {/* VIEW: Style Detail */}
        {/* ========================================== */}
        {view === "detail" && selectedStyle && (
          <div className="space-y-4 animate-fade-in">
            {/* Back button */}
            <button onClick={() => setView("grid")} className="text-sm text-accent hover:underline flex items-center gap-1">
              ← {t("detail_back")}
            </button>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Left: Illustration + Info */}
              <div className="space-y-4">
                <div className="rounded-xl border border-border overflow-hidden">
                  <img
                    src={`./assets/previews/${selectedStyle.id}.jpg`}
                    alt={t(selectedStyle.nameKey)}
                    className="w-full aspect-video object-cover"
                    onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                  />
                </div>

                <div className="bg-bg-card border border-border rounded-xl p-4 space-y-2">
                  <h3 className="text-lg font-bold">{t(selectedStyle.nameKey)}</h3>
                  <p className="text-sm text-text-dim">{selectedStyle.desc}</p>
                  <div className="flex gap-2 text-xs">
                    <span className="px-2 py-1 rounded-lg bg-bg border border-border text-text-dim">
                      {t("detail_model")}: {selectedStyle.asset}
                    </span>
                    <span className={`px-2 py-1 rounded-lg border font-medium ${
                      selectedStyle.model === "portrait" ? "bg-orange-500/10 border-orange-500/30 text-orange-400" :
                      selectedStyle.model === "universal" ? "bg-purple-500/10 border-purple-500/30 text-purple-400" :
                      "bg-green-500/10 border-green-500/30 text-green-400"
                    }`}>
                      {selectedStyle.model === "portrait" ? "👥 Portrait" :
                       selectedStyle.model === "universal" ? "🌐 Universal" : "🌄 Landscape"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Right: Live Preview from user's video */}
              <div className="space-y-4">
                <div className="bg-bg-card border border-border rounded-xl p-4">
                  <h4 className="text-sm font-semibold text-text-dim uppercase tracking-wider mb-3">{t("detail_preview")}</h4>

                  {!stylePreview && !previewLoading && (
                    <div className="aspect-video bg-black rounded-lg flex flex-col items-center justify-center gap-3">
                      <span className="text-3xl">🎬</span>
                      <button
                        onClick={generateStylePreview}
                        className="px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent-dim transition-colors"
                      >
                        {t("detail_generate")}
                      </button>
                    </div>
                  )}

                  {previewLoading && (
                    <div className="aspect-video bg-black rounded-lg flex flex-col items-center justify-center gap-2">
                      <span className="w-6 h-6 border-2 border-accent/30 border-t-accent rounded-full animate-spin" />
                      <span className="text-sm text-accent">{t("detail_generating")}</span>
                    </div>
                  )}

                  {stylePreview && !previewLoading && (
                    <div className="aspect-video bg-black rounded-lg overflow-hidden">
                      <img src={stylePreview} alt="preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>

                {/* Settings */}
                <div className="bg-bg-card border border-border rounded-xl p-4 space-y-3">
                  <h4 className="text-sm font-semibold text-text-dim uppercase tracking-wider">{t("detail_settings")}</h4>

                  <div className="space-y-1.5">
                    <label className="text-xs text-text-dim flex justify-between">
                      {t("intensity")}
                      <span className="text-accent font-mono">{settings.intensity}%</span>
                    </label>
                    <input type="range" min={10} max={100} value={settings.intensity}
                      onChange={e => setSettings(s => ({ ...s, intensity: Number(e.target.value) }))}
                      className="w-full h-1.5 bg-border rounded-full appearance-none accent-accent"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-xs text-text-dim">{t("fps")}</label>
                      <select value={settings.fps}
                        onChange={e => setSettings(s => ({ ...s, fps: Number(e.target.value) }))}
                        className="w-full px-2 py-1.5 bg-bg border border-border rounded-lg text-sm text-text outline-none"
                      >
                        <option value={24}>24</option>
                        <option value={30}>30</option>
                        <option value={60}>60</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs text-text-dim">{t("resolution")}</label>
                      <select value={settings.resolution}
                        onChange={e => setSettings(s => ({ ...s, resolution: e.target.value }))}
                        className="w-full px-2 py-1.5 bg-bg border border-border rounded-lg text-sm text-text outline-none"
                      >
                        <option value="original">{t("resolution_original")}</option>
                        <option value="1080">1080p</option>
                        <option value="720">720p</option>
                        <option value="480">480p</option>
                      </select>
                    </div>
                  </div>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={settings.keepAudio}
                      onChange={e => setSettings(s => ({ ...s, keepAudio: e.target.checked }))}
                      className="w-4 h-4 rounded border-border bg-bg text-accent"
                    />
                    <span className="text-sm text-text-dim">{t("keep_audio")}</span>
                  </label>

                  {/* Preview position */}
                  <div className="space-y-1">
                    <label className="text-xs text-text-dim">{t("preview_pos")}</label>
                    <div className="flex gap-1">
                      {(["start", "middle", "end", "custom"] as const).map(pos => (
                        <button key={pos}
                          onClick={() => setSettings(s => ({ ...s, previewPos: pos }))}
                          className={`flex-1 py-1 rounded text-[10px] font-medium border transition-all ${
                            settings.previewPos === pos ? "bg-accent/15 text-accent border-accent/30" : "bg-bg text-text-dim border-border"
                          }`}
                        >
                          {t(`preview_pos_${pos}`)}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-2">
                    <button onClick={() => runProcess("preview")} disabled={job.status === "running"}
                      className="flex-1 py-2.5 bg-bg border border-border text-text rounded-lg font-medium hover:bg-bg-card-hover transition-colors disabled:opacity-50 text-sm"
                    >
                      {job.type === "preview" && job.status === "running" ? t("processing") : t("action_preview")}
                    </button>
                    <button onClick={() => runProcess("export")} disabled={job.status === "running"}
                      className="flex-[2] py-2.5 bg-accent text-white rounded-lg font-medium hover:bg-accent-dim transition-colors disabled:opacity-50 text-sm"
                    >
                      {job.type === "export" && job.status === "running" ? t("processing") : t("action_export")}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Progress */}
            {job.status === "running" && (
              <div className="bg-bg-card border border-border rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{t("job_progress")}</span>
                  <button onClick={handleCancel} className="text-xs text-error hover:bg-error/10 px-2 py-1 rounded">{t("cancel")}</button>
                </div>
                <div className="h-2 bg-bg rounded-full overflow-hidden border border-border">
                  <div className="h-full bg-accent rounded-full transition-all duration-500" style={{ width: `${job.percent}%` }} />
                </div>
                <p className="text-xs text-text-dim">{job.message}</p>
              </div>
            )}

            {/* Error */}
            {error && <div className="bg-error/10 border border-error/30 rounded-xl p-3 text-sm text-error">{error}</div>}

            {/* Output */}
            {(previewOutputPath || outputPath) && (
              <div className="bg-bg-card border border-border rounded-xl p-4 space-y-3">
                <h3 className="text-sm font-semibold text-success">{outputPath ? t("done") : t("output")}</h3>
                <video src={outputPath ? outputSrc : previewOutSrc} className="w-full rounded-lg bg-black max-h-72" controls />
                <div className="flex gap-2">
                  <button onClick={handleSaveAs} className="flex-1 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent-dim">{t("save_as")}</button>
                  <button onClick={handleUseAsInput} className="flex-1 py-2 bg-bg border border-border rounded-lg text-sm font-medium hover:bg-bg-card-hover">{t("use_as_input")}</button>
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
