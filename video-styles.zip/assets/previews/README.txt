# Ilustračné náhľady štýlov

Vlož sem PNG/JPG náhľady pre každý štýl (rovnaký rozmer, napr. 400x300):
- anim_anime_hayao.jpg
- anim_anime_shinkai.jpg
- anim_cartoon.jpg
- anim_3d_cartoon.jpg
- anim_sketch.jpg
- anim_comic.jpg
- anim_watercolor.jpg
- anim_oilpaint.jpg
- anim_pixel.jpg
- style_inferno.jpg
- style_golden.jpg
- style_cyberpunk.jpg
- style_noir.jpg
- style_popart.jpg

Tieto sa zobrazia ako ilustračné ukážky v grile štýlov.
